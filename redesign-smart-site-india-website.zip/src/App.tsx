import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { Trust } from './components/Trust';
import { Services } from './components/Services';
import { Portfolio } from './components/Portfolio';
import { About } from './components/About';
import { Testimonials } from './components/Testimonials';
import { Contact } from './components/Contact';
import { Footer } from './components/Footer';
import { WhatsAppSticky } from './components/WhatsAppSticky';

export default function App() {
  return (
    <div className="min-h-screen bg-[#030712] text-slate-100 font-['Plus_Jakarta_Sans',sans-serif] selection:bg-emerald-500 selection:text-slate-950 relative overflow-hidden">
      
      {/* Top Background Gradient Enhancements */}
      <div className="absolute top-0 left-0 right-0 h-[600px] bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(16,185,129,0.1),rgba(255,255,255,0))] pointer-events-none"></div>
      
      {/* Primary Global Grid Lines */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b0a_1px,transparent_1px),linear-gradient(to_bottom,#1e293b0a_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_50%,#000_70%,transparent_100%)] pointer-events-none"></div>

      {/* Main Agency Application Stack */}
      <Navbar />
      
      <main>
        <Hero />
        <Trust />
        <Services />
        <Portfolio />
        <About />
        <Testimonials />
        <Contact />
      </main>

      <Footer />
      
      {/* Floating Action Elements */}
      <WhatsAppSticky />
      
    </div>
  );
}
