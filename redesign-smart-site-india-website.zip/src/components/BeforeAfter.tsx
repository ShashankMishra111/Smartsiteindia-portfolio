import { useState } from 'react';
import { ArrowLeftRight, Check, AlertCircle } from 'lucide-react';

export function BeforeAfter() {
  const [activeTab, setActiveTab] = useState<'after' | 'before'>('after');

  return (
    <div className="mt-16 p-6 sm:p-10 rounded-3xl bg-gradient-to-b from-slate-900/90 via-slate-950 to-slate-900/90 border border-slate-800/80 shadow-2xl relative overflow-hidden">
      
      {/* Absolute Badges */}
      <div className="absolute top-0 right-0 bg-gradient-to-l from-emerald-500/20 to-transparent px-8 py-2 text-[10px] font-bold text-emerald-400 tracking-widest uppercase">
        Live Case Study
      </div>

      <div className="max-w-4xl mx-auto">
        
        {/* Header Summary */}
        <div className="text-center md:text-left flex flex-col md:flex-row md:items-center justify-between gap-6 mb-8">
          <div>
            <div className="text-xs font-bold text-emerald-400 uppercase tracking-wider mb-1">Website Overhaul</div>
            <h3 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
              Real-World Redesign Impact
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              Slide or toggle to see how we transformed an outdated manufacturer's website into a modern lead engine.
            </p>
          </div>

          {/* Toggle Control */}
          <div className="inline-flex p-1.5 rounded-xl bg-slate-950 border border-slate-800 self-center">
            <button
              onClick={() => setActiveTab('before')}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${
                activeTab === 'before'
                  ? 'bg-rose-950/80 text-rose-300 border border-rose-800/50 shadow-sm'
                  : 'text-slate-500 hover:text-slate-300'
              }`}
            >
              Before Redesign
            </button>
            <button
              onClick={() => setActiveTab('after')}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${
                activeTab === 'after'
                  ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-950'
                  : 'text-slate-500 hover:text-slate-300'
              }`}
            >
              After (Smart Site India)
            </button>
          </div>
        </div>

        {/* Visual Wireframe Container */}
        <div className="relative rounded-2xl overflow-hidden border border-slate-800/80 bg-slate-950">
          
          {/* Browser Bar */}
          <div className="flex items-center justify-between px-4 py-2.5 bg-slate-900 border-b border-slate-800/80">
            <div className="flex items-center gap-1.5">
              <span className="h-2.5 w-2.5 rounded-full bg-slate-700"></span>
              <span className="h-2.5 w-2.5 rounded-full bg-slate-700"></span>
              <span className="h-2.5 w-2.5 rounded-full bg-slate-700"></span>
              <span className="text-[10px] text-slate-500 ml-2 font-mono">apex-industries-india.com</span>
            </div>
            
            <div>
              <span className={`text-[10px] px-2 py-0.5 rounded font-bold ${
                activeTab === 'after' 
                  ? 'bg-emerald-950 text-emerald-400 border border-emerald-800/50' 
                  : 'bg-rose-950 text-rose-400 border border-rose-800/50'
              }`}>
                {activeTab === 'after' ? '🚀 100% Mobile Ready' : '⚠️ Non-Responsive'}
              </span>
            </div>
          </div>

          {/* Interactive Pane */}
          <div className="transition-all duration-500">
            {activeTab === 'before' ? (
              /* BEFORE WIREFRAME */
              <div className="p-6 sm:p-10 bg-slate-200 text-slate-800 min-h-[340px] flex flex-col justify-between animate-fade-in">
                
                {/* Outdated Header */}
                <div className="border-b-2 border-slate-400 pb-4 flex justify-between items-center">
                  <div className="font-serif font-bold text-xl tracking-tighter text-red-800">
                    APEX INDUSTRIES LTD.
                  </div>
                  <div className="text-[10px] text-slate-600 hidden sm:block">
                    ESTD. 1998 | ISO 9001 CERTIFIED
                  </div>
                </div>

                {/* Clunky Content */}
                <div className="py-6 grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="md:col-span-2 space-y-3">
                    <h4 className="text-sm font-bold text-slate-900 uppercase underline">Welcome to Our Webpage</h4>
                    <p className="text-xs text-slate-700 leading-relaxed font-sans">
                      We are leading manufacturers of heavy duty industrial machine parts. We supply all over India. Our quality is very good and prices are competitive. Please browse our product catalog below. For orders, kindly call our landline number during office hours.
                    </p>
                    <div className="p-3 bg-amber-100 border border-amber-300 text-[11px] text-amber-900 rounded">
                      <span className="font-bold">Notice:</span> Website best viewed in Desktop resolution 1024x768. Mobile viewing may have overlapping text.
                    </div>
                  </div>

                  {/* Outdated Sidebar */}
                  <div className="bg-slate-300 p-4 border border-slate-400 space-y-3">
                    <div className="text-xs font-bold text-slate-900 bg-slate-400 px-2 py-1">Contact Us</div>
                    <div className="text-[11px] text-slate-700 space-y-1">
                      <div><strong className="text-slate-900">Tel:</strong> 011-2345678</div>
                      <div><strong className="text-slate-900">Fax:</strong> 011-2345679</div>
                      <div><strong className="text-slate-900">Email:</strong> apex1998@yahoo.com</div>
                    </div>
                    <button 
                      disabled 
                      className="w-full py-1 bg-slate-400 text-slate-700 text-[10px] font-bold cursor-not-allowed border border-slate-500"
                    >
                      Submit Enquiry (Broken)
                    </button>
                  </div>
                </div>

                {/* Before Audit Tags */}
                <div className="pt-4 border-t border-slate-300 flex flex-wrap gap-2">
                  <span className="inline-flex items-center gap-1 text-[10px] bg-red-100 text-red-800 px-2 py-0.5 rounded font-medium">
                    <AlertCircle className="h-3 w-3" /> 8.4s Load Time
                  </span>
                  <span className="inline-flex items-center gap-1 text-[10px] bg-red-100 text-red-800 px-2 py-0.5 rounded font-medium">
                    <AlertCircle className="h-3 w-3" /> No WhatsApp Trigger
                  </span>
                  <span className="inline-flex items-center gap-1 text-[10px] bg-red-100 text-red-800 px-2 py-0.5 rounded font-medium">
                    <AlertCircle className="h-3 w-3" /> Not Secure (No SSL)
                  </span>
                </div>

              </div>
            ) : (
              /* AFTER WIREFRAME */
              <div className="p-6 sm:p-10 bg-[#040915] text-slate-100 min-h-[340px] flex flex-col justify-between relative animate-fade-in">
                
                {/* Premium Background Elements */}
                <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none"></div>

                {/* Modern Header */}
                <div className="flex justify-between items-center pb-4 border-b border-slate-800/80">
                  <div className="flex items-center gap-2">
                    <div className="h-7 w-7 rounded-lg bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center font-bold text-slate-950 text-xs">
                      A
                    </div>
                    <span className="font-bold text-sm tracking-tight text-white">Apex Industries</span>
                  </div>

                  <div className="flex items-center gap-3">
                    <span className="text-[10px] text-slate-400 hidden sm:inline">Verified Manufacturer</span>
                    <button className="px-3 py-1 bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 rounded-full text-[10px] font-bold">
                      Direct WhatsApp
                    </button>
                  </div>
                </div>

                {/* High Converting Hero Layout inside the mockup */}
                <div className="py-6 grid grid-cols-1 md:grid-cols-3 gap-6 items-center">
                  <div className="md:col-span-2 space-y-4">
                    <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-slate-900 border border-slate-800 text-[10px] text-emerald-400 font-medium">
                      <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                      <span>Premium Heavy Duty Machine Components</span>
                    </div>

                    <h4 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight leading-tight">
                      Precision Industrial Parts Built For Scale
                    </h4>

                    <p className="text-xs text-slate-400 max-w-md leading-relaxed">
                      ISO 9001:2020 certified supply chains delivering premium parts to India's top manufacturing plants. Request wholesale samples instantly.
                    </p>

                    <div className="flex items-center gap-3 pt-1">
                      <div className="px-3 py-2 rounded-lg bg-emerald-500 text-slate-950 text-xs font-bold inline-flex items-center gap-1.5 shadow-md shadow-emerald-950">
                        <span>Get Wholesale Catalog</span>
                      </div>
                      <div className="text-[11px] text-slate-400">
                        ⚡ Response in 5 Mins
                      </div>
                    </div>
                  </div>

                  {/* Modern Trust Showcase */}
                  <div className="bg-slate-900/60 p-4 rounded-xl border border-slate-800/80 backdrop-blur-sm space-y-3">
                    <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Live Conversion Stats</div>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center text-xs">
                        <span className="text-slate-400">Monthly Leads</span>
                        <span className="font-bold text-emerald-400">420+</span>
                      </div>
                      <div className="flex justify-between items-center text-xs">
                        <span className="text-slate-400">Bounce Rate</span>
                        <span className="font-bold text-teal-400">&lt; 28%</span>
                      </div>
                      <div className="flex justify-between items-center text-xs">
                        <span className="text-slate-400">Mobile Score</span>
                        <span className="font-bold text-white">100/100</span>
                      </div>
                    </div>
                    <div className="pt-2 border-t border-slate-800 text-[9px] text-center text-slate-500">
                      Fully optimized by Smart Site India
                    </div>
                  </div>
                </div>

                {/* After Audit Tags */}
                <div className="pt-4 border-t border-slate-800/80 flex flex-wrap gap-2">
                  <span className="inline-flex items-center gap-1 text-[10px] bg-emerald-950/80 text-emerald-300 border border-emerald-800/40 px-2 py-0.5 rounded font-medium">
                    <Check className="h-3 w-3 text-emerald-400" /> 0.4s Load Time
                  </span>
                  <span className="inline-flex items-center gap-1 text-[10px] bg-emerald-950/80 text-emerald-300 border border-emerald-800/40 px-2 py-0.5 rounded font-medium">
                    <Check className="h-3 w-3 text-emerald-400" /> WhatsApp CTA Trigger
                  </span>
                  <span className="inline-flex items-center gap-1 text-[10px] bg-emerald-950/80 text-emerald-300 border border-emerald-800/40 px-2 py-0.5 rounded font-medium">
                    <Check className="h-3 w-3 text-emerald-400" /> Auto SEO Indexing
                  </span>
                </div>

              </div>
            )}
          </div>

        </div>

        {/* Footer comparison takeaway */}
        <div className="mt-6 text-center flex items-center justify-center gap-2 text-xs text-slate-400">
          <ArrowLeftRight className="h-3.5 w-3.5 text-emerald-400" />
          <span>
            Don't let an outdated design turn away serious Indian clients.{' '}
            <a 
              href="https://wa.me/917289971983?text=Hi%20Smart%20Site%20India,%20I%20want%20to%20redesign%20my%20old%20website." 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-white hover:text-emerald-400 font-bold underline"
            >
              Get a free redesign audit &rarr;
            </a>
          </span>
        </div>

      </div>

    </div>
  );
}
