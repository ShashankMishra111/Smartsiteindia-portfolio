import { Globe, Briefcase, LayoutTemplate, MessageSquareCode, Search, RefreshCw, ArrowUpRight } from 'lucide-react';

export function Services() {
  const services = [
    {
      title: "Business Websites",
      subtitle: "Corporate & Enterprise Solutions",
      description: "Premium, mobile-first professional websites tailored for Indian manufacturers, service providers, clinics, and real estate agencies to establish unshakeable market trust.",
      icon: Globe,
      features: ["Custom UI/UX Design", "High-Speed Optimization", "Secure Lead Capture Forms"],
      badge: "High Demand",
      gradient: "from-emerald-500/20 to-teal-500/10",
      accent: "text-emerald-400"
    },
    {
      title: "Portfolio Websites",
      subtitle: "Personal Brands & Agencies",
      description: "Showcase your work, case studies, and professional journey with hyper-modern layouts. Perfect for consultants, interior designers, architects, and freelance experts.",
      icon: Briefcase,
      features: ["Sleek Project Showcases", "Smooth Scroll Animations", "Client Testimonial Widgets"],
      badge: "Premium Vibe",
      gradient: "from-teal-500/20 to-cyan-500/10",
      accent: "text-teal-400"
    },
    {
      title: "Landing Pages",
      subtitle: "High-Converting Single Pages",
      description: "Laser-focused web pages engineered to maximize conversions for Google Ads, Facebook Ads, and digital marketing campaigns. Capture qualified leads instantly.",
      icon: LayoutTemplate,
      features: ["Persuasive CTA Placement", "A/B Ready Architecture", "Sub-Second Loading"],
      badge: "Best for Ads",
      gradient: "from-cyan-500/20 to-blue-500/10",
      accent: "text-cyan-400"
    },
    {
      title: "WhatsApp Integration",
      subtitle: "Instant Business Communication",
      description: "Seamless one-click WhatsApp chat buttons, auto-filled custom message triggers, and instant order capture systems designed for Indian buying behaviors.",
      icon: MessageSquareCode,
      features: ["Direct Lead Routing", "Mobile Chat Triggers", "Pre-filled Order Messages"],
      badge: "High Converting",
      gradient: "from-blue-500/20 to-indigo-500/10",
      accent: "text-blue-400"
    },
    {
      title: "SEO Optimization",
      subtitle: "Rank Higher on Google India",
      description: "Advanced local and national search engine optimization. We build clean semantic code, optimized schema markup, and blazing fast speeds to put you ahead of competitors.",
      icon: Search,
      features: ["Google Business Ready", "Technical Schema Audits", "Mobile Core Web Vitals"],
      badge: "Long Term Growth",
      gradient: "from-indigo-500/20 to-violet-500/10",
      accent: "text-indigo-400"
    },
    {
      title: "Website Redesign",
      subtitle: "Modernize Your Old Website",
      description: "Is your old website losing you customers? We completely overhaul outdated, slow websites into modern, trustworthy sales assets with complete data preservation.",
      icon: RefreshCw,
      features: ["Zero Downtime Migration", "Modern Visual Upgrade", "Preserved Search Rankings"],
      badge: "Transformative",
      gradient: "from-violet-500/20 to-purple-500/10",
      accent: "text-violet-400"
    }
  ];

  const getServiceWhatsApp = (serviceName: string) => {
    return `https://wa.me/917289971983?text=Hi%20Smart%20Site%20India,%20I%20am%20interested%20in%20your%20${encodeURIComponent(serviceName)}%20service.%20Please%20share%20details.`;
  };

  return (
    <section id="services" className="py-24 relative z-10">
      
      {/* Subtle Background Glow */}
      <div className="absolute top-1/2 left-0 w-[400px] h-[400px] bg-teal-500/5 rounded-full blur-[100px] pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-md bg-slate-900 border border-slate-800 text-xs font-semibold text-teal-400 mb-3">
            <span>Core Digital Capabilities</span>
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-white tracking-tight">
            Services That Drive <span className="text-gradient-premium">Real Results</span>
          </h2>
          <p className="mt-4 text-slate-400 text-sm sm:text-base">
            From sleek corporate footprints to high-speed WhatsApp marketing funnels, we cover the complete digital spectrum for ambitious Indian enterprises.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => {
            const IconComponent = service.icon;
            return (
              <div 
                key={index} 
                className="glass-card glass-card-hover p-8 rounded-2xl flex flex-col justify-between relative group"
              >
                {/* Premium Accent Top Tag */}
                <div className="absolute top-5 right-5">
                  <span className="px-2.5 py-1 rounded-full bg-slate-900 border border-slate-800 text-[10px] font-bold tracking-wide text-slate-300 uppercase">
                    {service.badge}
                  </span>
                </div>

                <div>
                  {/* Icon */}
                  <div className={`h-14 w-14 rounded-xl bg-gradient-to-br ${service.gradient} border border-slate-800/80 flex items-center justify-center mb-6 group-hover:scale-105 transition-transform`}>
                    <IconComponent className={`h-7 w-7 ${service.accent}`} />
                  </div>

                  {/* Titles */}
                  <h3 className="text-xl font-bold text-white tracking-tight group-hover:text-emerald-400 transition-colors">
                    {service.title}
                  </h3>
                  <p className="text-xs font-medium text-slate-400 mb-4 mt-0.5">
                    {service.subtitle}
                  </p>

                  {/* Description */}
                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed mb-6">
                    {service.description}
                  </p>

                  {/* Bullet Points */}
                  <div className="space-y-2 mb-8 pt-4 border-t border-slate-900/80">
                    {service.features.map((feat, fIdx) => (
                      <div key={fIdx} className="flex items-center gap-2 text-xs text-slate-400">
                        <span className="h-1 w-1 rounded-full bg-emerald-400"></span>
                        <span>{feat}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Footer Action */}
                <div>
                  <a
                    href={getServiceWhatsApp(service.title)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full py-3 px-4 rounded-xl bg-slate-900 hover:bg-emerald-950/40 text-slate-200 hover:text-emerald-400 font-bold text-xs flex items-center justify-between border border-slate-800 hover:border-emerald-800/40 transition-all group/btn"
                  >
                    <span>Enquire About This</span>
                    <ArrowUpRight className="h-4 w-4 text-slate-500 group-hover/btn:text-emerald-400 group-hover/btn:translate-x-0.5 group-hover/btn:-translate-y-0.5 transition-all" />
                  </a>
                </div>

              </div>
            );
          })}
        </div>

        {/* Custom Solution Callout */}
        <div className="mt-16 text-center">
          <p className="text-xs text-slate-500">
            Need a fully customized architecture or complex API platform?{' '}
            <a 
              href="#contact" 
              className="text-emerald-400 hover:underline font-semibold ml-1"
            >
              Let's craft a bespoke package for your business &rarr;
            </a>
          </p>
        </div>

      </div>

    </section>
  );
}
