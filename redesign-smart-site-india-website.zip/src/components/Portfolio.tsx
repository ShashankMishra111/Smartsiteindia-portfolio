import { ExternalLink, ArrowUpRight, Sparkles, CheckCircle2 } from 'lucide-react';
import { BeforeAfter } from './BeforeAfter';

export function Portfolio() {
  const projects = [
    {
      title: "Apex Heavy Industries",
      category: "B2B Manufacturer Website",
      description: "Complete corporate footprint featuring direct wholesale RFQ forms, mobile-optimized catalog, and multi-language support for international Indian export.",
      image: "https://images.pexels.com/photos/326514/pexels-photo-326514.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      stats: ["+210% Leads", "0.4s Load Speed"],
      tags: ["React", "Tailwind", "WhatsApp API"],
      linkText: "Live Client Preview"
    },
    {
      title: "Mehta Global Logistics",
      category: "Supply Chain & Cargo Portal",
      description: "High-converting online tracking platform with localized Indian SMS alerts, rate calculators, and fully streamlined contact forms that capture 40+ quotes daily.",
      image: "https://images.pexels.com/photos/12969403/pexels-photo-12969403.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      stats: ["40+ Daily Quotes", "100% Secure"],
      tags: ["Custom UI", "SEO Optimized", "Fast Delivery"],
      linkText: "Live Client Preview"
    },
    {
      title: "Deshmukh Premium Organics",
      category: "D2C Brand & E-Commerce",
      description: "Blazing fast online showcase optimized specifically for tier-1 and tier-2 Indian mobile shoppers. Integrated direct-to-WhatsApp instant ordering flow.",
      image: "https://images.pexels.com/photos/7191162/pexels-photo-7191162.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      stats: ["3.4x Conversion", "Mobile First"],
      tags: ["E-Commerce", "Payment Links", "Analytics"],
      linkText: "Live Client Preview"
    },
    {
      title: "Sharma Reality India",
      category: "Real Estate & Infra Catalog",
      description: "Sleek premium visual portal allowing high-net-worth investors to browse upcoming luxury projects with HD imagery, 3D walkthrough links, and quick schedule callouts.",
      image: "https://images.pexels.com/photos/15863066/pexels-photo-15863066.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      stats: ["140+ Site Visits", "Premium Trust"],
      tags: ["Luxury UI", "Lead Capturing", "High Fidelity"],
      linkText: "Live Client Preview"
    }
  ];

  return (
    <section id="portfolio" className="py-24 relative z-10 bg-slate-950/40 border-y border-slate-900/60">
      
      {/* Subtle Background Glow */}
      <div className="absolute bottom-1/3 right-0 w-[500px] h-[500px] bg-emerald-500/5 rounded-full blur-[120px] pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-md bg-emerald-950/50 border border-emerald-800/40 text-xs font-semibold text-emerald-400 mb-3">
            <Sparkles className="h-3.5 w-3.5" />
            <span>Proven Agency Results</span>
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-white tracking-tight">
            Our Premium <span className="text-gradient-premium">Project Showcase</span>
          </h2>
          <p className="mt-4 text-slate-400 text-sm sm:text-base">
            Explore recent premium web builds engineered for established Indian businesses. Every pixel is tailored for mobile responsiveness and lead generation.
          </p>
        </div>

        {/* Project Showcase Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {projects.map((project, index) => (
            <div 
              key={index} 
              className="glass-card glass-card-hover rounded-2xl overflow-hidden flex flex-col justify-between group"
            >
              
              {/* Image Container with Custom Hover Overlay */}
              <div className="relative aspect-video overflow-hidden bg-slate-900 border-b border-slate-800/80">
                <img 
                  src={project.image} 
                  alt={project.title}
                  className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500" 
                  loading="lazy"
                />
                
                {/* Premium Dark Gradient Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/30 to-transparent opacity-80 group-hover:opacity-60 transition-opacity"></div>

                {/* Floating Metric Badges */}
                <div className="absolute top-4 left-4 flex flex-wrap gap-2">
                  {project.stats.map((stat, sIdx) => (
                    <span 
                      key={sIdx} 
                      className="px-2.5 py-1 rounded-md bg-slate-950/80 backdrop-blur-md border border-slate-700/60 text-[10px] font-bold text-emerald-400 tracking-wide"
                    >
                      {stat}
                    </span>
                  ))}
                </div>

                {/* Category Label */}
                <div className="absolute bottom-3 left-4">
                  <span className="text-[10px] font-black uppercase tracking-wider text-teal-300 bg-slate-950/90 px-2 py-0.5 rounded">
                    {project.category}
                  </span>
                </div>
              </div>

              {/* Content Container */}
              <div className="p-6 sm:p-8 flex flex-col justify-between grow">
                <div>
                  
                  {/* Title */}
                  <h3 className="text-xl font-bold text-white tracking-tight mb-2 group-hover:text-emerald-400 transition-colors flex items-center justify-between">
                    <span>{project.title}</span>
                    <ArrowUpRight className="h-5 w-5 text-slate-500 group-hover:text-emerald-400 transition-colors" />
                  </h3>

                  {/* Description */}
                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed mb-6">
                    {project.description}
                  </p>

                  {/* Tech Tags */}
                  <div className="flex flex-wrap gap-1.5 mb-6">
                    {project.tags.map((tag, tIdx) => (
                      <span 
                        key={tIdx} 
                        className="px-2.5 py-0.5 rounded bg-slate-900 text-slate-400 text-[11px] font-medium border border-slate-800"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>

                </div>

                {/* Card Action */}
                <div className="pt-4 border-t border-slate-900/80 flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-xs text-slate-400">
                    <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" />
                    <span>100% Custom Delivery</span>
                  </div>
                  
                  <a
                    href="https://wa.me/917289971983?text=Hi%20Smart%20Site%20India,%20I%20loved%20your%20portfolio%20and%20want%20to%20build%20something%20similar."
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-xs font-bold text-emerald-400 hover:text-white transition-colors"
                  >
                    <span>{project.linkText}</span>
                    <ExternalLink className="h-3 w-3" />
                  </a>
                </div>

              </div>

            </div>
          ))}
        </div>

        {/* Before / After Module Showcase inside Portfolio */}
        <BeforeAfter />

        {/* CTA to start their project */}
        <div className="mt-16 text-center">
          <div className="inline-flex flex-col sm:flex-row items-center gap-4 p-2 pl-6 rounded-full bg-slate-900 border border-slate-800 max-w-xl mx-auto">
            <span className="text-xs text-slate-300 font-medium">
              Want a similar premium high-converting custom layout for your agency?
            </span>
            <a
              href="https://wa.me/917289971983?text=Hi%20Smart%20Site%20India,%20I%20want%20to%20view%20more%20designs%20for%20my%20business."
              target="_blank"
              rel="noopener noreferrer"
              className="px-5 py-2 rounded-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs whitespace-nowrap transition-all"
            >
              Get Custom Demo
            </a>
          </div>
        </div>

      </div>

    </section>
  );
}
