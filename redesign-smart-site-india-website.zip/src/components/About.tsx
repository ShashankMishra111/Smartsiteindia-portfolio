import { Award, CheckCircle2, HeartHandshake, Laptop, Sparkles, Target } from 'lucide-react';

export function About() {
  return (
    <section id="about" className="py-24 relative z-10">
      
      {/* Background ambient lighting */}
      <div className="absolute top-1/2 right-1/4 w-[400px] h-[400px] bg-blue-500/5 rounded-full blur-[100px] pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Side: Founder Story */}
          <div className="lg:col-span-7 space-y-6">
            
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-md bg-slate-900 border border-slate-800 text-xs font-semibold text-emerald-400">
              <HeartHandshake className="h-3.5 w-3.5" />
              <span>Founder-Focused Vision</span>
            </div>

            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-white tracking-tight leading-[1.15]">
              Bridging the Gap Between <br className="hidden sm:inline" />
              <span className="text-gradient-premium">Indian Ambition</span> & Global Digital Quality
            </h2>

            {/* Core User Specified Quote */}
            <div className="p-6 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-900/80 to-slate-950 border-l-4 border-emerald-500 shadow-xl">
              <p className="text-lg sm:text-xl text-slate-200 font-medium italic leading-relaxed">
                “Smart Site India helps small businesses create modern websites that look professional and attract customers online.”
              </p>
              <div className="mt-4 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse"></span>
                  <span className="text-xs font-bold text-emerald-400">Core Agency Philosophy</span>
                </div>
                <span className="text-[10px] text-slate-500 uppercase tracking-widest font-bold">100% Client-First</span>
              </div>
            </div>

            {/* Extended narrative for high conversion */}
            <div className="space-y-4 text-slate-300 text-sm sm:text-base leading-relaxed">
              <p>
                Too many Indian businesses are held back by amateur freelancers who deliver slow templates, stop answering calls after payment, or build sites that fail to convert mobile visitors.
              </p>
              <p>
                We established <strong className="text-white">Smart Site India</strong> to bring world-class UI/UX, transparent pricing, and instant WhatsApp workflows directly to ambitious small and medium enterprises. When you work with us, you deal with seasoned professionals who take full ownership of your digital identity.
              </p>
            </div>

            {/* Checklist of what sets us apart */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
              <div className="flex items-start gap-2.5">
                <div className="h-5 w-5 rounded bg-emerald-500/10 text-emerald-400 flex items-center justify-center shrink-0 mt-0.5">
                  <CheckCircle2 className="h-3.5 w-3.5" />
                </div>
                <span className="text-xs text-slate-300 font-medium">Direct WhatsApp access to core developers</span>
              </div>

              <div className="flex items-start gap-2.5">
                <div className="h-5 w-5 rounded bg-emerald-500/10 text-emerald-400 flex items-center justify-center shrink-0 mt-0.5">
                  <CheckCircle2 className="h-3.5 w-3.5" />
                </div>
                <span className="text-xs text-slate-300 font-medium">No cheap unoptimized WordPress drag-and-drop bloat</span>
              </div>

              <div className="flex items-start gap-2.5">
                <div className="h-5 w-5 rounded bg-emerald-500/10 text-emerald-400 flex items-center justify-center shrink-0 mt-0.5">
                  <CheckCircle2 className="h-3.5 w-3.5" />
                </div>
                <span className="text-xs text-slate-300 font-medium">Domain & customized email handholding included</span>
              </div>

              <div className="flex items-start gap-2.5">
                <div className="h-5 w-5 rounded bg-emerald-500/10 text-emerald-400 flex items-center justify-center shrink-0 mt-0.5">
                  <CheckCircle2 className="h-3.5 w-3.5" />
                </div>
                <span className="text-xs text-slate-300 font-medium">Optimized for Google India Local Search Results</span>
              </div>
            </div>

          </div>

          {/* Right Side: Visual Metrics & Premium Glass Stat Cards */}
          <div className="lg:col-span-5 relative">
            
            {/* Subtle rotating glow underlay */}
            <div className="absolute inset-0 bg-gradient-to-tr from-emerald-500/10 to-teal-500/10 rounded-3xl blur-2xl"></div>

            <div className="relative space-y-4">
              
              {/* Stat Card 1 */}
              <div className="glass-card p-6 rounded-2xl border border-slate-800/80 shadow-xl flex items-center gap-5">
                <div className="h-14 w-14 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center shrink-0">
                  <Target className="h-7 w-7 text-emerald-400" />
                </div>
                <div>
                  <div className="text-3xl font-extrabold text-white tracking-tight">100%</div>
                  <div className="text-xs font-bold text-emerald-400 uppercase tracking-wider mt-0.5">Client-Focused Delivery</div>
                  <div className="text-xs text-slate-400 mt-0.5">Custom websites designed to attract your specific target market.</div>
                </div>
              </div>

              {/* Stat Card 2 */}
              <div className="glass-card p-6 rounded-2xl border border-slate-800/80 shadow-xl flex items-center gap-5">
                <div className="h-14 w-14 rounded-xl bg-teal-500/10 border border-teal-500/20 flex items-center justify-center shrink-0">
                  <Laptop className="h-7 w-7 text-teal-400" />
                </div>
                <div>
                  <div className="text-3xl font-extrabold text-white tracking-tight">&lt; 1.0s</div>
                  <div className="text-xs font-bold text-teal-400 uppercase tracking-wider mt-0.5">Sub-Second Load Speeds</div>
                  <div className="text-xs text-slate-400 mt-0.5">Engineered to work flawlessly even on standard Indian 4G/5G mobile networks.</div>
                </div>
              </div>

              {/* Stat Card 3 */}
              <div className="glass-card p-6 rounded-2xl border border-slate-800/80 shadow-xl flex items-center gap-5">
                <div className="h-14 w-14 rounded-xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center shrink-0">
                  <Award className="h-7 w-7 text-blue-400" />
                </div>
                <div>
                  <div className="text-3xl font-extrabold text-white tracking-tight">24/7</div>
                  <div className="text-xs font-bold text-blue-400 uppercase tracking-wider mt-0.5">Continuous Direct Support</div>
                  <div className="text-xs text-slate-400 mt-0.5">Say goodbye to unattended support tickets. Instant answers over WhatsApp.</div>
                </div>
              </div>

              {/* Founder Direct Guarantee Overlay */}
              <div className="p-4 rounded-xl bg-gradient-to-r from-emerald-950/60 to-slate-900 border border-emerald-800/50 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Sparkles className="h-4 w-4 text-emerald-400 shrink-0" />
                  <span className="text-xs text-slate-300 font-medium">Ready to discuss your vision?</span>
                </div>
                <a
                  href="https://wa.me/917289971983?text=Hi%20Smart%20Site%20India,%20I%20read%20your%20founder%20story%20and%20want%20to%20build%20my%20website%20with%2>{' '}you."
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs font-bold text-emerald-400 hover:underline"
                >
                  Chat directly &rarr;
                </a>
              </div>

            </div>

          </div>

        </div>

      </div>

    </section>
  );
}
