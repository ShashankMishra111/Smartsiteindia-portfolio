import { useState, useEffect } from 'react';
import { MessageSquare, Menu, X, Sparkles, ChevronRight } from 'lucide-react';

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Services', href: '#services' },
    { name: 'Portfolio', href: '#portfolio' },
    { name: 'Why Us', href: '#trust' },
    { name: 'About', href: '#about' },
    { name: 'Testimonials', href: '#testimonials' },
  ];

  const whatsappUrl = "https://wa.me/917289971983?text=Hi%20Smart%20Site%20India,%20I%20am%20interested%20in%20building%20a%20modern%20website%20for%20my%20business.";

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      scrolled 
        ? 'bg-[#030712]/80 backdrop-blur-md py-3.5 border-b border-slate-800/60 shadow-xl shadow-black/20' 
        : 'bg-transparent py-5'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          
          {/* Brand Logo */}
          <a href="#" className="flex items-center gap-2.5 group">
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-emerald-500 to-teal-400 rounded-xl blur-sm opacity-60 group-hover:opacity-100 transition-opacity"></div>
              <div className="relative h-10 w-10 rounded-xl bg-slate-900 border border-slate-700/50 flex items-center justify-center">
                <Sparkles className="h-5 w-5 text-emerald-400" />
              </div>
            </div>
            <div className="flex flex-col">
              <span className="text-lg font-bold tracking-tight text-white group-hover:text-emerald-400 transition-colors flex items-center gap-1.5">
                Smart Site India
              </span>
              <span className="text-[10px] tracking-widest font-semibold uppercase text-emerald-400/90 -mt-1">
                Premium Web Agency
              </span>
            </div>
          </a>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-1 bg-slate-900/50 border border-slate-800/80 px-4 py-1.5 rounded-full backdrop-blur-sm">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="px-3.5 py-1.5 text-sm font-medium text-slate-300 hover:text-white hover:bg-slate-800/60 rounded-full transition-all"
              >
                {link.name}
              </a>
            ))}
          </nav>

          {/* Right side Actions */}
          <div className="hidden md:flex items-center gap-4">
            <a 
              href="#contact" 
              className="text-xs font-semibold text-slate-400 hover:text-slate-200 transition-colors"
            >
              Request Quote
            </a>
            
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="relative group overflow-hidden rounded-full p-[1px] transition-transform active:scale-95"
            >
              <span className="absolute inset-0 bg-gradient-to-r from-emerald-500 to-teal-400 transition-all duration-300 group-hover:opacity-100 opacity-80"></span>
              <span className="relative block px-4 py-2 rounded-full bg-slate-950 text-xs font-bold text-emerald-400 group-hover:bg-opacity-0 group-hover:text-slate-950 transition-all duration-300 flex items-center gap-1.5">
                <MessageSquare className="h-3.5 w-3.5 fill-current" />
                <span>Chat on WhatsApp</span>
              </span>
            </a>
          </div>

          {/* Mobile Menu Button */}
          <div className="flex md:hidden items-center gap-3">
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold text-xs rounded-full flex items-center gap-1"
            >
              <MessageSquare className="h-3 w-3 fill-current" />
              <span>Chat</span>
            </a>
            
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg bg-slate-900 text-slate-300 border border-slate-800 hover:text-white"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Overlay */}
      {mobileMenuOpen && (
        <div className="md:hidden absolute top-full left-0 right-0 bg-[#030712] border-b border-slate-800 py-6 px-6 shadow-2xl animate-fade-in">
          <div className="flex flex-col gap-3">
            <p className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Navigation</p>
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="py-2 text-base font-medium text-slate-200 hover:text-emerald-400 flex items-center justify-between border-b border-slate-900"
              >
                <span>{link.name}</span>
                <ChevronRight className="h-4 w-4 text-slate-600" />
              </a>
            ))}
            
            <div className="pt-4 mt-2 border-t border-slate-900 flex flex-col gap-3">
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-3 bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 font-bold rounded-xl text-center flex items-center justify-center gap-2 shadow-lg shadow-emerald-950/40"
              >
                <MessageSquare className="h-4 w-4 fill-current" />
                <span>Chat Instantly on WhatsApp</span>
              </a>
              <a
                href="#contact"
                onClick={() => setMobileMenuOpen(false)}
                className="w-full py-2.5 bg-slate-900 hover:bg-slate-850 text-slate-300 font-medium rounded-xl text-center text-sm border border-slate-800"
              >
                Send an Email Enquiry
              </a>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
