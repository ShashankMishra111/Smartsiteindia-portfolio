import { MessageSquare } from 'lucide-react';

export function WhatsAppSticky() {
  const whatsappUrl = "https://wa.me/917289971983?text=Hi%20Smart%20Site%20India,%20I%20am%20browsing%20your%20website%20and%20want%20to%20discuss%20a%20project.";

  return (
    <div className="fixed bottom-5 right-5 z-50 flex items-center gap-2 animate-fade-in">
      
      {/* Optional helper text bubble on desktop/larger screens */}
      <div className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-slate-900/90 backdrop-blur-md border border-slate-800 text-[11px] font-medium text-slate-300 shadow-xl">
        <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
        <span>Chat with Founder</span>
      </div>

      {/* Main pulsing sticky action button */}
      <a
        href={whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="relative group flex items-center justify-center"
        aria-label="Chat on WhatsApp"
      >
        {/* Pulsing Backdrops */}
        <span className="absolute inset-0 rounded-full bg-emerald-500 animate-ping opacity-30 group-hover:opacity-50"></span>
        <span className="absolute inset-0 rounded-full bg-gradient-to-tr from-emerald-600 to-teal-400 blur-sm opacity-60"></span>
        
        {/* Button Core */}
        <div className="relative h-13 w-13 sm:h-14 sm:w-14 rounded-full bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center text-slate-950 shadow-2xl shadow-emerald-950/80 transform group-hover:scale-105 active:scale-95 transition-all">
          <MessageSquare className="h-6 w-6 fill-current" />
          
          {/* Unread badge imitation for max urgency */}
          <span className="absolute top-0 right-0 h-3.5 w-3.5 rounded-full bg-rose-500 border-2 border-slate-950 flex items-center justify-center">
            <span className="text-[7px] font-black text-white">1</span>
          </span>
        </div>
      </a>

    </div>
  );
}
