import { Clock, Smartphone, IndianRupee, Users, Headphones, ShieldCheck } from 'lucide-react';

export function Trust() {
  const trustItems = [
    {
      title: "Fast Delivery",
      description: "Get your business website launched in record time. No endless delays, just premium execution.",
      icon: Clock,
      gradient: "from-emerald-500/20 to-teal-500/10",
      iconColor: "text-emerald-400"
    },
    {
      title: "Mobile Responsive",
      description: "Over 85% of Indian customers browse on phones. We craft flawless, lightning-fast mobile layouts.",
      icon: Smartphone,
      gradient: "from-teal-500/20 to-cyan-500/10",
      iconColor: "text-teal-400"
    },
    {
      title: "Affordable Pricing",
      description: "Premium global agency standards packaged specifically for Indian budgets. Transparent with zero hidden fees.",
      icon: IndianRupee,
      gradient: "from-cyan-500/20 to-blue-500/10",
      iconColor: "text-cyan-400"
    },
    {
      title: "Client Focused",
      description: "We listen carefully to your business goals. Your success is our reputation. Built to convert visitors into clients.",
      icon: Users,
      gradient: "from-blue-500/20 to-indigo-500/10",
      iconColor: "text-blue-400"
    },
    {
      title: "24/7 Support",
      description: "Direct access via WhatsApp. Whenever you need updates, maintenance, or advice, we are instantly here for you.",
      icon: Headphones,
      gradient: "from-indigo-500/20 to-violet-500/10",
      iconColor: "text-indigo-400"
    }
  ];

  return (
    <section id="trust" className="py-20 relative z-10 bg-slate-950/60 border-y border-slate-900/80">
      
      {/* Background Accent */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#030712] via-slate-950/40 to-[#030712] pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-md bg-emerald-950/60 border border-emerald-800/40 text-xs font-semibold text-emerald-400 mb-3">
            <ShieldCheck className="h-3.5 w-3.5" />
            <span>Why Indian Businesses Choose Us</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold text-white tracking-tight">
            Built for Premium Performance & <span className="text-gradient-premium">Absolute Trust</span>
          </h2>
          <p className="mt-3 text-slate-400 text-sm sm:text-base">
            We combine high-tier web aesthetics with bulletproof reliability so you can focus on scaling your business.
          </p>
        </div>

        {/* 5 Core Trust Pillars Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-6">
          {trustItems.map((item, index) => {
            const IconComponent = item.icon;
            return (
              <div 
                key={index} 
                className="glass-card glass-card-hover p-6 rounded-2xl flex flex-col justify-between relative group overflow-hidden"
              >
                {/* Subtle top border illumination */}
                <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-slate-700 group-hover:via-emerald-500 to-transparent transition-colors"></div>
                
                <div>
                  {/* Premium Icon Container */}
                  <div className={`h-12 w-12 rounded-xl bg-gradient-to-br ${item.gradient} border border-slate-800 flex items-center justify-center mb-5 group-hover:scale-110 transition-transform`}>
                    <IconComponent className={`h-6 w-6 ${item.iconColor}`} />
                  </div>

                  {/* Title */}
                  <h3 className="text-lg font-bold text-white mb-2 tracking-tight group-hover:text-emerald-400 transition-colors">
                    {item.title}
                  </h3>

                  {/* Description */}
                  <p className="text-xs text-slate-400 leading-relaxed">
                    {item.description}
                  </p>
                </div>

                {/* Bottom interactive indicator */}
                <div className="mt-6 pt-3 border-t border-slate-900/80 flex items-center justify-between">
                  <span className="text-[10px] font-mono text-slate-500">Pillar 0{index + 1}</span>
                  <span className="h-1.5 w-1.5 rounded-full bg-slate-700 group-hover:bg-emerald-400 transition-colors"></span>
                </div>

              </div>
            );
          })}
        </div>

        {/* Bottom stats marquee / guarantee banner */}
        <div className="mt-12 p-6 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-900/90 to-slate-900 border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-full bg-emerald-500/10 flex items-center justify-center shrink-0">
              <span className="text-lg">🤝</span>
            </div>
            <div>
              <div className="text-sm font-bold text-white">100% Satisfaction & Handholding Guarantee</div>
              <div className="text-xs text-slate-400">We personally guide you through domains, custom email setups, and updates.</div>
            </div>
          </div>
          <a
            href="https://wa.me/917289971983?text=Hi%20Smart%20Site%20India,%20I%20want%20to%20discuss%20pricing%20and%20timeline%20for%20my%20website."
            target="_blank"
            rel="noopener noreferrer"
            className="px-5 py-2.5 rounded-xl bg-slate-950 hover:bg-emerald-950/40 text-emerald-400 text-xs font-bold border border-emerald-800/40 transition-all whitespace-nowrap"
          >
            Ask About Pricing
          </a>
        </div>

      </div>

    </section>
  );
}
