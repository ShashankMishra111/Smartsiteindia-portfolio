import { Star, Quote, CheckCircle2 } from 'lucide-react';

export function Testimonials() {
  const testimonials = [
    {
      name: "Vikram Mehta",
      role: "Founder, Mehta Logistics & Exports",
      image: "https://images.pexels.com/photos/7580994/pexels-photo-7580994.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
      review: "Smart Site India completely transformed our supply chain website. Our clients in Delhi and Mumbai now request quotes instantly through the WhatsApp integration. Leads have increased by over 200%. True professionals who deliver on time!",
      rating: 5,
      location: "New Delhi, India"
    },
    {
      name: "Dr. Anjali Deshmukh",
      role: "Director, Deshmukh Dental & Aesthetics",
      image: "https://images.pexels.com/photos/7688183/pexels-photo-7688183.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
      review: "As a clinic owner, I needed a beautiful, trustworthy website where patients could easily book consultations on their mobile phones. The Smart Site India team guided me through every single step. Absolutely premium quality and exceptional 24/7 support.",
      rating: 5,
      location: "Pune, India"
    },
    {
      name: "Rajesh Sharma",
      role: "Managing Partner, Sharma Realty & Infra",
      image: "https://images.pexels.com/photos/7580940/pexels-photo-7580940.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
      review: "We previously wasted money on a clunky site that took 10 seconds to load. Smart Site India rebuilt our portfolio with lightning-fast speeds and amazing modern animations. High-net-worth property investors are consistently impressed by our web presence.",
      rating: 5,
      location: "Gurugram, India"
    }
  ];

  return (
    <section id="testimonials" className="py-24 relative z-10 bg-slate-950/60 border-t border-slate-900/60">
      
      {/* Background ambient gradient */}
      <div className="absolute top-1/3 left-1/4 w-[400px] h-[400px] bg-emerald-500/5 rounded-full blur-[100px] pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-md bg-slate-900 border border-slate-800 text-xs font-semibold text-emerald-400 mb-3">
            <span>Client Success Stories</span>
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-white tracking-tight">
            Trusted by Ambitious <br className="hidden sm:inline" />
            <span className="text-gradient-premium">Indian Businesses</span>
          </h2>
          <p className="mt-4 text-slate-400 text-sm sm:text-base">
            Read direct feedback from founders and directors who upgraded their agency footprint to Smart Site India.
          </p>
        </div>

        {/* Testimonials Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testi, index) => (
            <div 
              key={index} 
              className="glass-card p-8 rounded-2xl flex flex-col justify-between relative group hover:border-slate-700 transition-all"
            >
              
              {/* Subtle top quotes background */}
              <div className="absolute top-4 right-4 opacity-5 group-hover:opacity-10 transition-opacity">
                <Quote className="h-20 w-20 text-white" />
              </div>

              <div>
                
                {/* Five Stars Rating */}
                <div className="flex items-center gap-1 mb-6">
                  {[...Array(testi.rating)].map((_, i) => (
                    <Star key={i} className="h-4 w-4 fill-amber-400 text-amber-400" />
                  ))}
                  <span className="text-xs font-bold text-slate-300 ml-2">5.0 / 5.0</span>
                </div>

                {/* Review Text */}
                <p className="text-sm text-slate-200 leading-relaxed italic mb-8 relative z-10">
                  "{testi.review}"
                </p>

              </div>

              {/* Author Info Container */}
              <div className="pt-4 border-t border-slate-900/80 flex items-center gap-4 relative z-10">
                
                {/* Profile Image */}
                <div className="relative h-12 w-12 rounded-full overflow-hidden bg-slate-800 border border-emerald-500/30 shrink-0">
                  <img 
                    src={testi.image} 
                    alt={testi.name} 
                    className="w-full h-full object-cover object-center"
                    loading="lazy"
                  />
                </div>

                {/* Author Details */}
                <div className="flex flex-col">
                  <div className="flex items-center gap-1.5">
                    <span className="text-sm font-bold text-white tracking-tight">{testi.name}</span>
                    <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" />
                  </div>
                  <span className="text-xs font-medium text-slate-400">{testi.role}</span>
                  <span className="text-[10px] text-slate-500 font-semibold uppercase tracking-wider mt-0.5">{testi.location}</span>
                </div>

              </div>

            </div>
          ))}
        </div>

        {/* Global summary badge */}
        <div className="mt-12 text-center">
          <p className="text-xs text-slate-500">
            Join over 100+ satisfied businesses who have elevated their online sales and credibility.{' '}
            <a 
              href="#contact" 
              className="text-emerald-400 hover:underline font-semibold ml-1"
            >
              Start your journey today &rarr;
            </a>
          </p>
        </div>

      </div>

    </section>
  );
}
