import { ArrowRight, CheckCircle2, MessageSquare, ShieldCheck, Zap } from 'lucide-react';

export function Hero() {
  const whatsappUrl = "https://wa.me/917289971983?text=Hi%20Smart%20Site%20India,%20I%20am%20interested%20in%20building%20a%20modern%20website%20for%20my%20business.";

  return (
    <section className="relative pt-32 pb-20 md:pt-40 md:pb-32 overflow-hidden">
      
      {/* Premium Ambient Gradients */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] md:w-[700px] md:h-[700px] bg-gradient-to-tr from-emerald-600/20 via-teal-500/10 to-slate-900/0 rounded-full blur-[120px] pointer-events-none"></div>
      <div className="absolute top-1/3 right-[-10%] w-[400px] h-[400px] bg-emerald-500/10 rounded-full blur-[100px] pointer-events-none"></div>

      {/* Subtle Matrix Background Grid */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b12_1px,transparent_1px),linear-gradient(to_bottom,#1e293b12_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_40%,#000_70%,transparent_100%)] pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Main Hero Content */}
        <div className="max-w-4xl mx-auto text-center">
          
          {/* Trust Banner */}
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-slate-900/90 border border-slate-800 text-xs text-slate-300 mb-8 animate-fade-in">
            <span className="flex h-2 w-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <span className="font-semibold text-emerald-400">🇮🇳 #1 Trusted Agency</span>
            <span className="text-slate-600">|</span>
            <span>Premium Web Solutions for Indian Businesses</span>
          </div>

          {/* Headline */}
          <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-extrabold text-white tracking-tight leading-[1.1] mb-6">
            We Build Websites That <br className="hidden sm:inline" />
            <span className="text-gradient-premium relative">
              Grow Your Business
              <span className="absolute bottom-1 left-0 w-full h-[4px] bg-emerald-500/30 blur-xs"></span>
            </span>
          </h1>

          {/* Subheadline */}
          <p className="text-lg sm:text-xl text-slate-300 max-w-2xl mx-auto mb-10 leading-relaxed font-normal">
            Modern websites for businesses that want more customers, trust, and sales online.
          </p>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-14">
            
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto px-8 py-4 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-bold text-base shadow-xl shadow-emerald-950/40 transition-all transform hover:-translate-y-0.5 active:translate-y-0 flex items-center justify-center gap-2.5 group"
            >
              <MessageSquare className="h-5 w-5 fill-current" />
              <span>Chat on WhatsApp</span>
              <span className="inline-block px-1.5 py-0.5 bg-slate-950/10 rounded text-[10px] uppercase font-black tracking-wider text-slate-950">Instant</span>
            </a>

            <a
              href="#portfolio"
              className="w-full sm:w-auto px-8 py-4 rounded-xl bg-slate-900/80 hover:bg-slate-800 text-white font-semibold text-base border border-slate-700/60 backdrop-blur-sm transition-all flex items-center justify-center gap-2 group"
            >
              <span>View Portfolio</span>
              <ArrowRight className="h-4 w-4 text-slate-400 group-hover:text-white group-hover:translate-x-1 transition-all" />
            </a>

          </div>

          {/* Core Trust Attributes for instant validation */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-3xl mx-auto pt-6 border-t border-slate-900/80">
            <div className="flex items-center justify-center gap-2 text-slate-400 text-xs font-medium">
              <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
              <span>100% Custom Code</span>
            </div>
            <div className="flex items-center justify-center gap-2 text-slate-400 text-xs font-medium">
              <Zap className="h-4 w-4 text-emerald-400 shrink-0" />
              <span>Lightning Fast Speed</span>
            </div>
            <div className="flex items-center justify-center gap-2 text-slate-400 text-xs font-medium">
              <ShieldCheck className="h-4 w-4 text-emerald-400 shrink-0" />
              <span>Secure Hosting</span>
            </div>
            <div className="flex items-center justify-center gap-2 text-slate-400 text-xs font-medium">
              <MessageSquare className="h-4 w-4 text-emerald-400 shrink-0" />
              <span>WhatsApp Integrated</span>
            </div>
          </div>

        </div>

        {/* Premium Graphical Dashboard Preview */}
        <div className="mt-16 max-w-5xl mx-auto relative group">
          
          {/* Subtle Glowing Underlay */}
          <div className="absolute inset-0 bg-gradient-to-r from-emerald-500/20 to-teal-500/20 rounded-2xl blur-xl group-hover:opacity-100 transition-opacity opacity-60"></div>
          
          <div className="relative rounded-2xl bg-slate-950 border border-slate-800 shadow-2xl overflow-hidden">
            
            {/* Window Browser Header */}
            <div className="flex items-center justify-between px-4 py-3 bg-slate-900/90 border-b border-slate-800/80">
              <div className="flex items-center gap-2">
                <span className="h-3 w-3 rounded-full bg-rose-500/80"></span>
                <span className="h-3 w-3 rounded-full bg-amber-500/80"></span>
                <span className="h-3 w-3 rounded-full bg-emerald-500/80"></span>
                <div className="ml-2 px-2 py-0.5 bg-slate-950 rounded text-[10px] font-mono text-slate-400 flex items-center gap-1.5">
                  <span className="text-emerald-400">🔒</span> www.smartsiteindia.top
                </div>
              </div>

              <div className="flex items-center gap-3">
                <span className="text-[10px] font-semibold text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800/50">
                  OPTIMIZED FOR MOBILE & DESKTOP
                </span>
              </div>
            </div>

            {/* Dashboard Mockup Content */}
            <div className="p-4 sm:p-8 grid grid-cols-1 md:grid-cols-3 gap-6 bg-[#040915]">
              
              {/* Left Column: Business Growth Preview */}
              <div className="space-y-4">
                <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800/60">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-medium text-slate-400">WhatsApp Enquiries</span>
                    <span className="text-xs font-bold text-emerald-400">+340%</span>
                  </div>
                  <div className="text-2xl font-extrabold text-white">1,482 Leads</div>
                  <div className="mt-2 h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
                    <div className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 w-[85%]"></div>
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800/60">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-medium text-slate-400">Page Load Time</span>
                    <span className="text-xs font-bold text-emerald-400">0.4s</span>
                  </div>
                  <div className="flex items-baseline gap-2">
                    <span className="text-2xl font-extrabold text-white">99/100</span>
                    <span className="text-[10px] text-slate-400">Google PageSpeed</span>
                  </div>
                  <div className="mt-2.5 flex gap-1">
                    <span className="h-1 w-full bg-emerald-500 rounded-full"></span>
                    <span className="h-1 w-full bg-emerald-500 rounded-full"></span>
                    <span className="h-1 w-full bg-emerald-500 rounded-full"></span>
                    <span className="h-1 w-full bg-emerald-500 rounded-full"></span>
                  </div>
                </div>
              </div>

              {/* Center & Right Column: Website Wireframe */}
              <div className="md:col-span-2 rounded-xl bg-slate-900/30 border border-slate-800/50 p-4 sm:p-6 flex flex-col justify-between relative overflow-hidden">
                <div className="absolute top-0 right-0 p-4 opacity-10">
                  <Zap className="h-32 w-32 text-emerald-400" />
                </div>
                
                <div className="space-y-4 relative z-10">
                  <div className="flex items-center justify-between border-b border-slate-800/40 pb-3">
                    <div className="flex items-center gap-2">
                      <div className="h-6 w-6 rounded bg-emerald-500/20 flex items-center justify-center">
                        <span className="text-xs font-bold text-emerald-400">S</span>
                      </div>
                      <span className="text-xs font-bold text-slate-200">Premium Client Dashboard</span>
                    </div>
                    <span className="text-[10px] text-slate-400">Live Status: <span className="text-emerald-400 font-bold">Active</span></span>
                  </div>

                  <div className="space-y-2">
                    <div className="h-4 w-3/4 bg-slate-800/60 rounded"></div>
                    <div className="h-3 w-1/2 bg-slate-800/40 rounded"></div>
                  </div>

                  <div className="grid grid-cols-2 gap-3 pt-2">
                    <div className="p-3 rounded-lg bg-slate-900/80 border border-slate-800/40">
                      <div className="text-[10px] text-slate-400">Direct Conversion</div>
                      <div className="text-sm font-bold text-emerald-400 mt-0.5">8.7% Avg.</div>
                    </div>
                    <div className="p-3 rounded-lg bg-slate-900/80 border border-slate-800/40">
                      <div className="text-[10px] text-slate-400">Mobile Optimization</div>
                      <div className="text-sm font-bold text-teal-400 mt-0.5">100% Native</div>
                    </div>
                  </div>
                </div>

                <div className="pt-4 mt-4 border-t border-slate-800/40 flex items-center justify-between relative z-10">
                  <div className="flex items-center gap-2">
                    <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse"></span>
                    <span className="text-[10px] text-slate-300 font-medium">Ready for local SEO & Google Search</span>
                  </div>
                  <span className="text-[10px] text-emerald-400 font-semibold flex items-center gap-1">
                    High Conversion Mode <ArrowRight className="h-2.5 w-2.5" />
                  </span>
                </div>

              </div>

            </div>

          </div>

        </div>

      </div>

    </section>
  );
}
