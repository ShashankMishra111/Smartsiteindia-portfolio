import { Sparkles, ArrowUp } from 'lucide-react';

export function Footer() {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#02050d] border-t border-slate-900 text-slate-400 py-12 relative z-10">
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Main Footer Layout */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 pb-12 border-b border-slate-900">
          
          {/* Brand Info */}
          <div className="md:col-span-2 space-y-4">
            <a href="#" className="flex items-center gap-2 group inline-flex">
              <div className="h-8 w-8 rounded-lg bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center text-slate-950">
                <Sparkles className="h-4 w-4" />
              </div>
              <span className="text-base font-bold text-white tracking-tight">Smart Site India</span>
            </a>
            
            <p className="text-xs text-slate-500 max-w-sm leading-relaxed">
              We build premium, high-converting digital assets specifically configured for the growing Indian market. Experience lightning-fast load speeds and seamless WhatsApp automation.
            </p>

            <div className="text-[11px] text-slate-600">
              Designed for absolute performance. Optimized for Google India search.
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-3">
            <div className="text-xs font-bold text-white uppercase tracking-wider">Navigation</div>
            <ul className="space-y-2 text-xs">
              <li><a href="#services" className="hover:text-emerald-400 transition-colors">Core Services</a></li>
              <li><a href="#portfolio" className="hover:text-emerald-400 transition-colors">Project Showcase</a></li>
              <li><a href="#trust" className="hover:text-emerald-400 transition-colors">Why Choose Us</a></li>
              <li><a href="#about" className="hover:text-emerald-400 transition-colors">Founder Story</a></li>
              <li><a href="#testimonials" className="hover:text-emerald-400 transition-colors">Client Reviews</a></li>
            </ul>
          </div>

          {/* Legal / Contact Summary */}
          <div className="space-y-3">
            <div className="text-xs font-bold text-white uppercase tracking-wider">Consulting Desk</div>
            <ul className="space-y-2 text-xs">
              <li>
                <span className="block text-slate-600">WhatsApp Hotline:</span>
                <a href="https://wa.me/917289971983" target="_blank" rel="noopener noreferrer" className="text-slate-300 hover:text-emerald-400 font-semibold">
                  +91 7289971983
                </a>
              </li>
              <li>
                <span className="block text-slate-600">Enquiry Email:</span>
                <a href="mailto:smartsiteindia1111@gmail.com" className="text-slate-300 hover:text-emerald-400 font-semibold">
                  smartsiteindia1111@gmail.com
                </a>
              </li>
              <li className="pt-1">
                <span className="inline-block px-2 py-0.5 bg-slate-900 text-emerald-400 rounded text-[10px]">
                  🇮🇳 Registered Agency
                </span>
              </li>
            </ul>
          </div>

        </div>

        {/* Bottom Copyright Row */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          
          <div className="text-xs text-slate-500 text-center sm:text-left">
            © 2026 Smart Site India — All Rights Reserved
          </div>

          <div className="flex items-center gap-4 text-xs text-slate-600">
            <span>Privacy Policy</span>
            <span>•</span>
            <span>Terms of Service</span>
            <span>•</span>
            <span>Sitemap</span>
          </div>

          {/* Back to Top */}
          <button
            onClick={scrollToTop}
            className="p-2 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white transition-all border border-slate-800 flex items-center gap-1.5 text-xs"
            aria-label="Back to top"
          >
            <span>Back to top</span>
            <ArrowUp className="h-3.5 w-3.5" />
          </button>

        </div>

      </div>

    </footer>
  );
}
