import React, { useState } from 'react';
import { MessageSquare, Mail, Send, CheckCircle2, ArrowRight, ShieldCheck } from 'lucide-react';

export function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    businessName: '',
    phone: '',
    service: 'Business Website',
    message: ''
  });

  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const whatsappNumber = "917289971983";
  const emailAddress = "smartsiteindia1111@gmail.com";

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    // Simulate high-speed secure API transmission
    setTimeout(() => {
      setLoading(false);
      setSubmitted(true);
    }, 800);
  };

  // Generate customized message from their filled details
  const getCustomWhatsAppLink = () => {
    const text = `Hi Smart Site India, I have submitted an inquiry on your website.%0A%0A*Name:* ${formData.name}%0A*Business:* ${formData.businessName}%0A*Phone:* ${formData.phone}%0A*Service:* ${formData.service}%0A*Message:* ${formData.message}`;
    return `https://wa.me/${whatsappNumber}?text=${text}`;
  };

  const directWhatsAppUrl = `https://wa.me/${whatsappNumber}?text=Hi%20Smart%20Site%20India,%20I%20want%20to%20build%20a%20high-converting%20website%20for%20my%20business.`;

  return (
    <section id="contact" className="py-24 relative z-10 bg-slate-950 border-t border-slate-900/80">
      
      {/* Background Ambience */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-to-tr from-emerald-600/10 via-teal-500/5 to-transparent rounded-full blur-[140px] pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          
          {/* Left Column: Direct Agency Contacts & Value Proposition */}
          <div className="lg:col-span-5 space-y-8">
            
            <div>
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-md bg-slate-900 border border-slate-800 text-xs font-semibold text-emerald-400 mb-3">
                <span>Start Your Transformation</span>
              </div>
              <h2 className="text-3xl sm:text-4xl font-bold text-white tracking-tight">
                Let's Build Something <span className="text-gradient-premium">Extraordinary</span>
              </h2>
              <p className="mt-4 text-slate-300 text-sm leading-relaxed max-w-md">
                Whether you need a brand new website, an urgent redesign, or an advanced WhatsApp automation portal, our team is ready to deliver.
              </p>
            </div>

            {/* Premium Direct Contact Cards */}
            <div className="space-y-4">
              
              {/* WhatsApp Primary Contact Box */}
              <div className="p-5 rounded-2xl bg-gradient-to-br from-slate-900 to-slate-950 border border-emerald-500/30 shadow-lg relative overflow-hidden group">
                <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/10 rounded-full blur-xl group-hover:bg-emerald-500/20 transition-colors"></div>
                
                <div className="flex items-start gap-4 relative z-10">
                  <div className="h-12 w-12 rounded-xl bg-emerald-500 text-slate-950 flex items-center justify-center shrink-0 font-bold shadow-md shadow-emerald-950">
                    <MessageSquare className="h-6 w-6 fill-current" />
                  </div>
                  
                  <div className="space-y-1 grow">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Official WhatsApp</span>
                      <span className="text-[10px] font-bold text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-800/40">
                        ⚡ Instant Reply
                      </span>
                    </div>
                    
                    <div className="text-lg font-bold text-white tracking-tight">
                      +91 7289971983
                    </div>
                    
                    <p className="text-xs text-slate-400">
                      Tap below to message our lead developer instantly.
                    </p>

                    <div className="pt-2">
                      <a
                        href={directWhatsAppUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-400 hover:text-white transition-colors"
                      >
                        <span>Open WhatsApp Chat</span>
                        <ArrowRight className="h-3.5 w-3.5" />
                      </a>
                    </div>
                  </div>
                </div>
              </div>

              {/* Email Contact Box */}
              <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800/80 flex items-start gap-4">
                <div className="h-12 w-12 rounded-xl bg-slate-800 text-teal-400 flex items-center justify-center shrink-0 border border-slate-700">
                  <Mail className="h-5 w-5" />
                </div>
                
                <div className="space-y-1">
                  <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">Direct Email</span>
                  <a 
                    href={`mailto:${emailAddress}`}
                    className="text-base font-bold text-white hover:text-teal-400 transition-colors block break-all"
                  >
                    {emailAddress}
                  </a>
                  <p className="text-xs text-slate-400">
                    For official RFPs, custom attachments, and corporate tenders.
                  </p>
                </div>
              </div>

              {/* Operating Hours & Trust Guarantee */}
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-900 flex items-center gap-3">
                <ShieldCheck className="h-5 w-5 text-emerald-400 shrink-0" />
                <div className="text-xs text-slate-400">
                  <span className="text-slate-200 font-semibold block">100% Secure & Confidential</span>
                  We never share your business concepts or phone numbers with any third parties.
                </div>
              </div>

            </div>

            {/* Social Media Link */}
            <div className="pt-2">
              <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3">Connect With Us</div>
              <div className="flex items-center gap-3">
                <a
                  href="https://instagram.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="h-10 w-10 rounded-xl bg-slate-900 hover:bg-gradient-to-tr hover:from-amber-500 hover:via-rose-500 hover:to-purple-600 border border-slate-800 flex items-center justify-center text-slate-400 hover:text-white transition-all group"
                  aria-label="Instagram"
                >
                  <svg className="h-4 w-4 fill-current group-hover:scale-110 transition-transform" viewBox="0 0 24 24">
                    <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
                  </svg>
                </a>
                <span className="text-xs text-slate-400">Follow our latest responsive client UI drops</span>
              </div>
            </div>

          </div>

          {/* Right Column: Premium Interactive Contact Form */}
          <div className="lg:col-span-7">
            
            <div className="glass-card p-6 sm:p-10 rounded-3xl border border-slate-800/80 shadow-2xl relative">
              
              {submitted ? (
                /* SUCCESS STATE */
                <div className="py-12 text-center space-y-6 animate-fade-in">
                  <div className="h-16 w-16 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto">
                    <CheckCircle2 className="h-10 w-10" />
                  </div>
                  
                  <div className="space-y-2">
                    <h3 className="text-2xl font-bold text-white tracking-tight">Enquiry Received Successfully!</h3>
                    <p className="text-sm text-slate-300 max-w-md mx-auto">
                      Thank you <strong className="text-white">{formData.name}</strong>. Our elite development team has been instantly notified of your requirements for <strong className="text-emerald-400">{formData.service}</strong>.
                    </p>
                  </div>

                  <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 max-w-md mx-auto text-left space-y-2">
                    <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Fast-Track Your Request</div>
                    <p className="text-xs text-slate-300">
                      Want to skip the queue? Send your pre-filled inquiry straight to our WhatsApp for immediate attention:
                    </p>
                    
                    <a
                      href={getCustomWhatsAppLink()}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs rounded-lg flex items-center justify-center gap-2 transition-all mt-2"
                    >
                      <MessageSquare className="h-4 w-4 fill-current" />
                      <span>Send Details to WhatsApp Now</span>
                    </a>
                  </div>

                  <button
                    onClick={() => {
                      setSubmitted(false);
                      setFormData({ name: '', businessName: '', phone: '', service: 'Business Website', message: '' });
                    }}
                    className="text-xs text-slate-500 hover:text-slate-300 underline pt-2"
                  >
                    Submit another inquiry
                  </button>

                </div>
              ) : (
                /* INPUT FORM */
                <form onSubmit={handleSubmit} className="space-y-5">
                  
                  <div className="border-b border-slate-800/80 pb-4 mb-2">
                    <h3 className="text-xl font-bold text-white tracking-tight">Request a Free Project Proposal</h3>
                    <p className="text-xs text-slate-400 mt-1">Fill out the brief fields below. We typically respond with examples and pricing within 15 minutes.</p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    {/* Your Name */}
                    <div className="space-y-1.5">
                      <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider">
                        Your Name <span className="text-emerald-400">*</span>
                      </label>
                      <input
                        type="text"
                        name="name"
                        required
                        value={formData.name}
                        onChange={handleChange}
                        placeholder="e.g. Rahul Sharma"
                        className="w-full px-4 py-3 rounded-xl bg-slate-900/90 border border-slate-800 text-white text-sm focus:outline-none focus:border-emerald-500 transition-colors"
                      />
                    </div>

                    {/* Business Name */}
                    <div className="space-y-1.5">
                      <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider">
                        Business / Agency Name <span className="text-emerald-400">*</span>
                      </label>
                      <input
                        type="text"
                        name="businessName"
                        required
                        value={formData.businessName}
                        onChange={handleChange}
                        placeholder="e.g. Apex Enterprises"
                        className="w-full px-4 py-3 rounded-xl bg-slate-900/90 border border-slate-800 text-white text-sm focus:outline-none focus:border-emerald-500 transition-colors"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    {/* Phone / WhatsApp */}
                    <div className="space-y-1.5">
                      <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider">
                        WhatsApp / Phone Number <span className="text-emerald-400">*</span>
                      </label>
                      <div className="relative">
                        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-500">
                          +91
                        </span>
                        <input
                          type="tel"
                          name="phone"
                          required
                          value={formData.phone}
                          onChange={handleChange}
                          placeholder="98765 43210"
                          className="w-full pl-10 pr-4 py-3 rounded-xl bg-slate-900/90 border border-slate-800 text-white text-sm focus:outline-none focus:border-emerald-500 transition-colors"
                        />
                      </div>
                    </div>

                    {/* Service Required */}
                    <div className="space-y-1.5">
                      <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider">
                        Primary Service Required
                      </label>
                      <select
                        name="service"
                        value={formData.service}
                        onChange={handleChange}
                        className="w-full px-4 py-3 rounded-xl bg-slate-900/90 border border-slate-800 text-white text-sm focus:outline-none focus:border-emerald-500 transition-colors"
                      >
                        <option value="Business Website">Business Website</option>
                        <option value="Portfolio Website">Portfolio Website</option>
                        <option value="Landing Page">Landing Page</option>
                        <option value="WhatsApp Integration">WhatsApp Integration</option>
                        <option value="SEO Optimization">SEO Optimization</option>
                        <option value="Website Redesign">Website Redesign</option>
                      </select>
                    </div>
                  </div>

                  {/* Project Details */}
                  <div className="space-y-1.5">
                    <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider">
                      Tell Us About Your Goals
                    </label>
                    <textarea
                      name="message"
                      rows={3}
                      value={formData.message}
                      onChange={handleChange}
                      placeholder="Share your existing domain, target audience, or any design inspiration websites you like..."
                      className="w-full px-4 py-3 rounded-xl bg-slate-900/90 border border-slate-800 text-white text-sm focus:outline-none focus:border-emerald-500 transition-colors resize-none"
                    ></textarea>
                  </div>

                  {/* Submit Button */}
                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full py-4 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-bold text-sm shadow-xl shadow-emerald-950/30 transition-all flex items-center justify-center gap-2 group disabled:opacity-70"
                  >
                    {loading ? (
                      <>
                        <span className="h-4 w-4 rounded-full border-2 border-slate-950 border-t-transparent animate-spin"></span>
                        <span>Encrypting & Sending...</span>
                      </>
                    ) : (
                      <>
                        <span>Get Free Proposal & Timeline</span>
                        <Send className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
                      </>
                    )}
                  </button>

                  <div className="text-center">
                    <span className="text-[11px] text-slate-500">
                      ⚡ By clicking above, your inquiry is securely dispatched directly to the core Indian consulting desk.
                    </span>
                  </div>

                </form>
              )}

            </div>

          </div>

        </div>

      </div>

    </section>
  );
}
